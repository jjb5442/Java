package in;

import java.util.Scanner;

public class Quiz5 {
	public static void main(String[] args) {
		// 지하철 한 구간당 평균 소요 시간이 3분이라고 가정한다
		// 이동한 구간수를 입력받아서, 걸린 시간을 화면에 출력하세요
		// 시간과 분을 나누어서 출력하며, 한자릿수라면 앞에 0을 붙여서 출력하세요
		// 입력 : 7
		// 출력 : 00시간 21분	// if를 사용할 수 있다면 0시간 없이 그냥 분만 출력할 수도 있습니다
		
		// 입력 : 21
		// 출력 : 01시간 03분
		
		Scanner sc = new Scanner(System.in);
		int move, hour, minute, step = 3;
		
		System.out.print("이동 구간 수 : ");
		move = sc.nextInt();
		
		minute = move * step;	// 이동에 걸린 시간이 몇분인지 계산하고
		hour = minute / 60;		// 시간과 분을 나누어서 저장한다
		minute = minute % 60;
		
		System.out.printf("%02d시간 %02d분\n", hour, minute);
		
		sc.close();
	}
}
