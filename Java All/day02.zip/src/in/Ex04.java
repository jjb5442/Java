package in;

import java.util.Scanner;	// #include <stdio.h> 처럼 입력을 처리하기 위해 선언

public class Ex04 {
//	여기 내용은 그냥 한번만 읽어보세요
//	System.in 	: 자바에서 기본 입력을 담당하는 객체 -> 이클립스에서 녹색 글자로 표시
//	System.out 	: 자바에서 기본 출력을 담당하는 객체 -> 이클립스에서 검정색 글자로 표시
//	System.err	: 자바에서 에러 출력을 담당하는 객체 -> 이클립스에서 빨간색 글자로 표시
//	IO : Input and Output (입출력)
	
	public static void main(String[] args) {
//		System.in 은 기본적으로 1바이트씩 입력을 받는다 (한글 하나도 정상적으로 입력할 수 없다)
//		System.in을 이용하여 2바이트 단위로 입력받는 객체를 만들수 있다
//		위 객체를 이용하여 버퍼(일정 크기의 그릇)단위로 입력받는 객체를 만들 수도 있다
//		사용자 입력 발생시 여러 상황의 문제가 발생할 수 있어서 문제(예외)처리도 추가해야 한다
//		편리하게 입력받을 수 있는 별도의 입력 객체를 만들어서 입력을 처리하게 된다 -> Scanner
		
		Scanner sc = new Scanner(System.in);	// 키보드 입력받는 객체
		
		// char를 제외한 모든 primitive와 String을 입력받을 수 있다
		
		System.out.print("이름 입력 : ");
		String name = sc.next();	// 사용자의 입력을 문자열 형태로 돌려주는 기능
		
		System.out.print("나이 입력 : ");
		int age = sc.nextInt();		// 사용자의 입력을 정수 형태로 돌려주는 기능
		
		System.out.printf("%s의 나이는 %d살입니다\n", name, age);
		
		sc.close(); // sc를 생성하면 통로가 개설된다. 이 통로는 사용이 끝나면 반드시 닫아야 한다
	}
}






