package in;

import java.util.Scanner;

public class Ex05 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);	// 입력을 처리하는 객체
		
		String name;
		int kor, eng, mat, sum;
		double avg;
		
		System.out.print("이름 입력 : "); 	// 바로 입력부터 받으면 사용자가 알아채기 힘들다
		name = sc.next(); 				// 문자열을 입력받는 함수
		
		System.out.print("국어 점수 입력 : ");
		kor = sc.nextInt();
		System.out.print("영어 점수 입력 : ");
		eng = sc.nextInt();
		System.out.print("수학 점수 입력 : ");
		mat = sc.nextInt();
		
		sum = kor + eng + mat;	// 입력받기 전에 미리 식을 쓰면 안된다
		avg = sum / 3.0;
		
		String form = "%s의 합계는 %d점이고, 평균은 %.2f점입니다\n";
		System.out.printf(form, name, sum, avg);
		sc.close(); // close() 이후에는 입력을 처리할 수 없다 (항상 마지막에 닫아주기)
	}
}
