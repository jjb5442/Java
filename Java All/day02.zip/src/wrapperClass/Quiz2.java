package wrapperClass;

public class Quiz2 {	// 문자열을 제외한 모든 자료형은 primitive 타입으로 처리합니다
	public static void main(String[] args) {
		// 이름을 저장할 수 있는 변수를 생성하고, 자신의 이름으로 초기화하세요
		String name = "이지은";
		
		// 나이를 저장할 수 있는 변수를 생성하고, 자신의 나이로 초기화하세요
		int age = 30;
		
		// double 형 변수를 생성하고, 0으로 초기화하세요
		double db = 0;
		
		// 위에서 만든 변수에 3.14를 대입하세요
		db = 3.14;
		
		// float 형 변수를 생성하고 위에서 만든 값을 대입하세요
		float fl = (float)db;
		
	}
}
