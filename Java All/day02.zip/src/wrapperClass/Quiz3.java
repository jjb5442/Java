package wrapperClass;

public class Quiz3 {
	public static void main(String[] args) {// primitive 없이 처리하세요
		// 이름을 저장할 수 있는 변수를 생성하고, 자신의 이름으로 초기화하세요
		String name = "이지은";
		
		// 나이를 저장할 수 있는 변수를 생성하고, 자신의 나이로 초기화하세요
		Integer age = 30;
		
		// double 형 변수를 생성하고, 0으로 초기화하세요
		Double db = 0.0;	// literal도 data이고, 따라서 dataType을 가진다
		
		// 위에서 만든 변수에 3.14를 대입하세요
		db = 3.14;
		
		// float 형 변수를 생성하고 위에서 만든 값을 대입하세요
//		Float fl = (float)(double)db;	// primitive를 거쳐서 형변환하기
		Float fl = db.floatValue();		// WrapperClass의 기능을 활용하기
	}
}
