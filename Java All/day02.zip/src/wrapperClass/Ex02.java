package wrapperClass;

public class Ex02 {
	public static void main(String[] args) {
		int num = 10;		// 비 객체형, 단순히 데이터만 저장한다
		Integer num2 = 10;	// 객체형, 데이터도 저장하고, 여러 기능을 포함한다
		
		// 비객체형 데이터가 스스로 움직일 수 없는 인형이라면
		// 객체형 데이터는 일반적으로 자체적인 기능을 포함하는 형식이며, 데이터도 여러값을 저장할 수 있다
		// 단, wrapper Class는 primitive와 같이 값은 하나만 저장한다
		
//		num.	비 객체형 데이터는 내부에 단순 데이터만 저장되어 있어서 기능을 호출할 수 없다
//		num2.	.뒤에 자료형에 내장된 여러 기능(함수)을 호출할 수 있도록 되어 있다
		
		// 1) 자신과 호환되는 primitive 타입과 1:1 대응된다
		// 2) primitive 간에는 유형만 맞으면 값을 옮겨담을 수 있다
		// 3) Wrapper Class 간에는 유형이 맞아도 값을 옮겨담을 수 없다
		// -> 타입 체크가 좀 더 자세해야 한다
		
		byte by = 1;
		num = by;		// primitive 라면 같은 정수끼리 혹은 정수 및 실수끼리 값을 옮겨담는다
		
		double db = num;
		
		// Wrapper Class 는 명확하게 일치할 경우에만 옮겨담을 수 있다
		Byte b2 = 20;
		num2 = (int)(byte)b2;
		
		// 혹은, Wrapper Class에 내장된 기능(함수)을 이용하여 변환할 수 있다
		num2 = b2.intValue();
		
		
		
		
	}
}
