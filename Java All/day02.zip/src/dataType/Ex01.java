package dataType;

public class Ex01 {
	public static void main(String[] args) {
		int n1 = 200;	// 정수를 4byte 크기의 공간에 저장
		byte n2 = 100;	// 정수를 1byte 크기의 공간에 저장
		
		System.out.println("n1 : " + n1);
		System.out.println("n2 : " + n2);
		
		n1 = n2;	// n2(1byte)의 값을 n1(4byte)의 공간에 복사하여 저장한다
		// 1) 값을 대입할 때는 왼쪽과 오른쪽의 자료형이 같아야 한다
		// 2) 왼쪽의 자료형이 더 크다면, 직접 적지 않아도 자동으로 형태가 변환된다 (자동 형변환)
		// 3) 왼쪽의 자료형이 더 작다면, 데이터 손실의 가능성이 존재한다
		n1 = 200;
		n2 = 100;
		
		n2 = (byte)n1; 	// 강제 형 변환, 명시적 형 변환
		System.out.println("n1 : " + n1);
		System.out.println("n2 : " + n2);
		
		// 1) 왼쪽의 자료형 크기가 더 작은 경우
		// 2) 왼쪽과 오른쪽의 데이터 유형이 서로 다른 경우 (문자열 변수에 정수를 담을 수 없다)
		// 3) 값의 범위가 일치하지 않는 경우
		
	}
}
