package dataType;

public class Quiz1 {
	public static void main(String[] args) {
		byte by = 10;
		short sh = 20;
		char ch = 65;
		int num = 30;
		long lo = 40L;		// 그냥 적으면 int로 생각해서 long이라는걸 구분하기 위해서 L 작성
		float fl = 3.14F;	// 그냥 적으면 double로 생각해서 float이라는걸 구분하기 위해서 F 작성
		double db = 97.56;
		
		int a = by;			// promotion, 자료형 변환을 별도로 작성할 필요 없음
		char b = (char)db;	// casting, 명시적 형 변환을 작성해야 한다 -> 실수값을 정수변수에 대입
		long c = sh;		// promotion
		float d = num;		// promotion	
		short e = (short)ch;// casting, 정수값을 정수변수에 대입 -> 값의 표현범위가 다르다
		double f = by;		// promotion
		
		System.out.println("b : " + b);
		System.out.println("e : " + e);
	}
}
