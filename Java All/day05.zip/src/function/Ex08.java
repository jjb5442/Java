package function;

public class Ex08 {
	static int summary(int n1, int n2) {	// 두 정수 사이의 합계를 반환
		int sum = 0;
		for(int i = n1; i <= n2; i++) {
			sum += i;
		}
		return sum;
	}
	static int summary(int num) {	// 1부터 num까지의 합계
		int sum = summary(1, num);
		return sum;
	}
	static int summary(int[] arr) {	// 배열의 각 숫자의 합을 반환
		int sum = 0;
		for(int i = 0; i < arr.length; i++) {
			sum += arr[i];	// 합계에 더할 값이 i인지 arr[i]인지 구분하자
		}
		return sum;
	}
	public static void main(String[] args) {
		// 디버깅 시작 : F11
		// 함수호출 코드에서 함수로 진입 : F5
		// 함수호출 코드에서 함수를 스킵 : F6
		// 특정 구간 혹은 여러 정수의 합계를 구하여 반환하는 함수
		
		// 1) 두 정수를 전달받아서 두 수 사이의 합계를 반환 (첫번째에 작은 수를 넣어야 한다)
		int n1 = summary(1, 10);
		int n2 = summary(5, 15);
		
		// 2) 정수형태의 배열을 전달받아서 배열 요소의 합계를 반환
		int[] arr = { 2, 7, 8, 4, 6 };
		int n3 = summary(arr);
		
		// 3) 정수를 하나 전달받아서, 1부터 전달받은 수 까지의 합계를 반환
		int n4 = summary(10);
		
		System.out.println(n1);		// 55
		System.out.println(n2);		// 110
		System.out.println(n3); 	// 27
		System.out.println(n4);		// 55
	}
}
