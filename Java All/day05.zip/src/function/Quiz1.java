package function;

public class Quiz1 {
	// 함수 작성 공간 y = f(x)
	static int summary(int n1, int n2) {
		int sum = 0;	// 첫줄에서는 반환형의 변수를 만들고 초기화한다
		
		int start = n1 < n2 ? n1 : n2;	// 시작값(작은값)
		int end = n1 >= n2 ? n1 : n2;	// 끝값(큰값)
		for(int i = start; i <= end; i++) {	// 작은값부터 큰값까지 1씩 증가하면서 합산
			sum += i;
		}
		
		return sum;		// 마지막줄에서는 첫줄의 변수를 return 한다
	}
	
	static double average(int n1, int n2, int n3) {
		double avg = 0;
		
		avg = (n1 + n2 + n3) / 3.0; 	// 합계 나누기 개수
		
		return avg;
	}
	
	static String getReadableSize(long size) {
		String data = "";	// String data = null;
		
		// 1) size값이 1024보다 작은 값이 나와야 한다
		// 2) size값을 1024로 나눈 값은 1024보다 작거나 크다
		// 3) 나눈값이 1024보다 작아질때 까지 계속 나눈다
		// 4) 나눈 횟수가 몇번이냐에 따라서 단위가 달라진다
		double db = size;		// 실수 형태로 계산하기 위해서 옮겨담기
		int cnt = 0;			// 나눈 횟수를 체크하기 위한 변수
		while(true) {		
			db = db / 1024;		// db값을 1024로 나눈다
			cnt++;				// 횟수를 1 증가시킨다
			if(db < 1024) {		// 만약 나눈 값이 1024보다 작으면 반복 중단
				break;
			}
		}
		data = String.format("%.2f", db);	// 실수를 소수점 둘째자리까지만 만들기
		switch(cnt) {
			case 0: data += " Byte"; 	break;	// 한번도 나누지 않았으면 Byte
			case 1: data += " KB"; 		break;	// 횟수에 따라서 단위를 더해준다
			case 2: data += " MB"; 		break;
			case 3: data += " GB"; 		break;
			case 4: data += " TB"; 		break;
		}
		return data;	// 결과 반환
	}
	
	public static void main(String[] args) {
		// 1) 두 정수를 전달받아서, 두 정수 사이의 합계를 정수형태로 반환하는 함수
		int q1 = summary(10, 1);		// 두 수의 대소관계 상관없이 사이값의 합계를 구함
		System.out.println(q1); 		// 55
		
		// 2) 세 정수를 전달받아서, 세 정수의 평균값을 실수형태로 반환하는 함수
		double q2 = average(100, 99, 87);
		System.out.println(q2); 		// 95.333333
		
		// 3) 파일의 용량을 byte단위로 long형태로 전달받아서, 문자열형식으로 반환하는 함수
		// 1024byte = 1KB, 1024KB = 1MB, 1024MB = 1GB, 1024GB = 1TB
		String q3 = getReadableSize(3991928832L);
		System.out.println(q3); 	// 1.39 MB
	}
}
