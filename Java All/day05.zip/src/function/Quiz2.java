package function;

public class Quiz2 {
	public static void main(String[] args) {
		// 카드번호 16자리를 받아서, 4자리씩 구분하여 사이에 - 기호를 넣어서 반환하는 함수
		
		char[] arr = {
			'1','2','3','4','5','6','7','8',
			'3','4','5','6','7','8','9','0'
		};
		
		String data1 = cardNumber(1234567834567890L);	// long
		String data2 = cardNumber("1234567834567890");	// String
		String data3 = cardNumber(arr);					// char[]
		
		System.out.println(data1);	// 1234-5678-3456-7890
		System.out.println(data2);	// 1234-5678-3456-7890
		System.out.println(data3);	// 1234-5678-3456-7890
	}
	static String cardNumber(String num) {		// 문자열을 전달받아서 중간에 - 를 추가하는 함수
		String result = "";
		for(int i = 1; i <= num.length(); i++) {
			result += num.charAt(i - 1);
			if(i % 4 == 0 && i != num.length()) {	// 마지막 값은 제외
				result += "-";
			}
		}
		return result;
	}
	static String cardNumber(char[] arr) {	// char[]을 문자열 형태로 바꾸고, 위 함수에게 다시 전달
		String num = new String(arr);	// char[] 을 이용하여 새로운 문자열을 만든다
		return cardNumber(num);			// 만들어진 문자열을 전달하면 String을 받는 코드가 실행된다
	}
	static String cardNumber(long n) {	// long을 문자열 형태로 바꾸고, 위 함수에게 다시 전달
		return cardNumber(n + "");
	}
	
}



