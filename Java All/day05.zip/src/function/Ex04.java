package function;

import java.util.Random;
import java.util.Scanner;

public class Ex04 {
	public static void main(String[] args) {
		// 함수를 사용하지 않고 엘리베이터 문제 풀기
		// A, B, C 3개의 엘리베이터가 있다
		// 각 엘리베이터는 현재 층이 랜덤으로 정해지고
		// 사용자가 입력한 숫자에 가장 가까운 엘리베이터가 이동하면 된다
		// 건물의 높이는 지상1층부터 지상 15층까지
		
		// 현재 사용자의 위치와, 각 엘리베이터의 거리 중 최소값을 구해야 한다
		// 거리는 음수가 나오면 안된다 (절대값)
		// 서로 다른 3개의 정수중에서 최소값을 찾아야 한다
		
		Scanner sc = new Scanner(System.in);
		Random ran = new Random();
		
		int a, b, c, user;
		a = ran.nextInt(15) + 1;	// 1 ~ 15
		b = ran.nextInt(15) + 1;
		c = ran.nextInt(15) + 1;
		
		System.out.printf("a : %d, b : %d, c : %d\n", a, b, c);
		System.out.print("사용자의 층 수를 입력 : ");
		user = sc.nextInt();
		
		int distA, distB, distC;	// 현재층과 각 엘리베이터의 거리를 저장
		distA = user - a;	// 층수의 차이(뺄셈)
		distB = user - b;
		distC = user - c;
		
		distA = distA < 0 ? -distA : distA;	// 절대값
		distB = distB < 0 ? -distB : distB;
		distC = distC < 0 ? -distC : distC;
		
		int min = 16;	// 최소값을 구하려면 가장 큰 값을 미리 넣어두고 시작한다
		if(min > distA)		min = distA;
		if(min > distB)		min = distB;
		if(min > distC)		min = distC;
		
		System.out.printf("%d, %d, %d\n", distA, distB, distC);
		System.out.println("거리의 최소값 : " + min);
		
		if(min == distA) 		System.out.println("A가 움직입니다");
		else if(min == distB) 	System.out.println("B가 움직입니다");
		else if(min == distC) 	System.out.println("C가 움직입니다");
		
		sc.close();
	}
}