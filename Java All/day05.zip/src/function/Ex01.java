package function;

// 어떤 유형(dataType)의 데이터를 어떤 방식(method, function)으로 처리할 것인가?
// 함수 : 데이터를 일정한 방식으로 처리하는 코드 (코드의 집합, 묶음)
// y = f(x) : x를 전달받아서 일정한 수식 f에 따라 연산하고, 결과값 y가 나온다
// 음료수 = 자판기(돈)

public class Ex01 {
	static String 자판기(int 돈) {				// 이런 기능이 있습니다 (정의, define)
		if(돈 == 500) 		return "사이다"; 
		else if(돈 == 600) 	return "콜라";
		else if(돈 == 800) 	return "포카리스웨트";
		else 				return null;
	}
	public static void main(String[] args) {
		String test1 = 자판기(500); 	// y = f(x)
		String test2 = 자판기(600);	// 만들어진 기능을 실행합니다 (호출, call)
		String test3 = 자판기(700);
		String test4 = 자판기(800);
		
		System.out.println(test1);
		System.out.println(test2);
		System.out.println(test3);
		System.out.println(test4);
		System.out.println(자판기(500));
	}
}




