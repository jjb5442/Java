package function;

import java.util.Random;
import java.util.Scanner;

public class Ex05 {
	static int getDistance(int user, int e) {
		int result = user - e;	// 두 값의 차이를 구하고
		if(result < 0) 			// 만약 결과가 0보다 작으면
			result = -result;	// 부호를 반전시켜서 +로 만든다 (절대값)
		return result;			// 만들어진 값을 반환한다
	}
	static int getMinimum(int a, int b, int c) {
		int min = a;			// a가 최소값이라고 가정하고
		if(min > b) 	min = b;// b가 더 작으면 b를 최소값으로 지정
		if(min > c) 	min = c;// c가 더 작으면 c를 최소값으로 지정
		return min;				// 마지막으로 결정된 최소값을 반환한다
	}
	
	public static void main(String[] args) {
		// Ex04의 문제에서 함수를 만들어서 사용하면 어떻게 바뀌는가?
		// 1) 사용자 입력값과 각 층수와의 거리를 절대값으로 구할 수 있어야 한다
		// 2) 3개의 거리값중에서 최소값을 구해야 한다
		Scanner sc = new Scanner(System.in);
		Random ran = new Random();
		
		int a = ran.nextInt(15) + 1;
		int b = ran.nextInt(15) + 1;
		int c = ran.nextInt(15) + 1;
		
		System.out.printf("엘리베이터 위치 : %d, %d, %d\n", a, b, c);
		System.out.print("현재 층 수 입력 : ");
		int user = sc.nextInt();
		
		int distA = getDistance(user, a);
		int distB = getDistance(user, b);
		int distC = getDistance(user, c);
		
		int min = getMinimum(distA, distB, distC);
		
		if(min == distA)  		System.out.println("A가 움직입니다");
		else if(min == distB)  	System.out.println("B가 움직입니다");
		else if(min == distC)  	System.out.println("C가 움직입니다");
		
		sc.close();
	}
}
