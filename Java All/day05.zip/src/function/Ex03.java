package function;

public class Ex03 {
	// 1) 함수의 정의
	static int reverse(int num) {	// num을 전달받아서, ret을 반환하는 함수
		int ret = 0;
		while(true) {
			ret += num % 10;	// 0 -> 4 -> 43 -> 432
			ret *= 10;			// 4 -> 40, 43 -> 430, 432 -> 4320
			num /= 10;			// 1234 -> 123, 123 -> 12, 12 -> 1
			if(num < 10) {		
				ret += num;		// 4320 + 1
				break;
			}
		}
		return ret;	// return 4321;
	}
	// 함수를 하나 만들어두면, 이후 필요할때 마다 여러번 불러서 사용할 수 있다 (코드의 재사용)
	public static void main(String[] args) {
		int n1 = reverse(1234);
		int n2 = reverse(13579);
		int n3 = reverse(9876);
		
		System.out.println(n1);
		System.out.println(n2);
		System.out.println(n3);
	}
}
