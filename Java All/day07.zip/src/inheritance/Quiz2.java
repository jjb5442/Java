package inheritance;

class Quiz {		// 퀴즈의 형식만 만들어둔 클래스
	
	int n1;
	int n2;
	
	Quiz(int n1, int n2) {
		this.n1 = n1;
		this.n2 = n2;
	}
	public int getAnswer() {
		return 0;
	}
}
// Quiz 클래스를 상속받아서 새로운 클래스 2개를 작성하고 테스트해보세요
// 1) 두 정수의 합을 반환하는 함수를 가지는 클래스, getAnswer() 의 내용을 새로 만들어서 덮어쓰면 됩니다 (오버라이딩)
class SumN1andN2 extends Quiz {
	// 서브클래스의 생성자는 슈퍼클래스의 생성자를 호출할 수 있어야 한다
	SumN1andN2(int n1, int n2) {
		super(n1, n2);
	}
	// 상속받은 메서드는 형식을 유지하면서 내용을 바꿀 수 있다 (메서드 오버라이딩)
	@Override	// 이 함수는 상속받는 내용을 변경한 함수입니다
	public int getAnswer() {
		return n1 + n2;
	}
}
// 2) 두 정수 사이의 합을 반환하는 함수를 가지는 클래스
class SumBetweenN1andN2 extends Quiz {
	SumBetweenN1andN2(int n1, int n2) {
		super(n1, n2);
	}
	@Override
	public int getAnswer() {
		int sum = 0;
		// 반복문 활용
//		for(int i = n1; i <= n2; i++) {
//			sum += i;
//		}
		// 등차수열의 합
		sum = (n1 + n2) * (n2 - n1 + 1) / 2;
		return sum;
	}
}
public class Quiz2 {
	public static void main(String[] args) {
		SumN1andN2 ob1 = new SumN1andN2(1, 10);
		int n1 = ob1.getAnswer();
		
		SumBetweenN1andN2 ob2 = new SumBetweenN1andN2(1, 10000000);
		double start = System.nanoTime();
		int n2 = ob2.getAnswer();
		double end = System.nanoTime();
		double elapsedTime = end - start;
		System.out.println("걸린 시간 : " + elapsedTime);
		
		System.out.println(n1); 	// 11
		System.out.println(n2); 	// 55
	}
}
