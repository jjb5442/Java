package inheritance;

import java.util.Scanner;

class Phone2 {
	Scanner sc = new Scanner(System.in);
	static int sequence = 1000;
	int id;
	
	Phone2() {
		sequence += 1000;
		this.id = sequence;
	}
	
	// 보내는 경우
	void sendMessage(Phone2 target) {	// 나와 같은 자료형의 다른 객체를 참조하는 target
		System.out.printf("%d) 보낼 메시지 입력 : ", id);
		String message = sc.nextLine();
		System.out.println();
		target.takeMessage(message, this);	// 객체 자기 자신을 가리키는 this
	}
	
	// 받는 경우
	void takeMessage(String message, Phone2 sender) {
		System.out.printf("%d) %d으로부터 메시지 도착\n", id, sender.id);
		System.out.printf("%d : %s\n\n", sender.id, message);
	}
}

class SmartPhone2 extends Phone2 {
	
	void web() throws Exception {
		System.out.print("주소 입력 : ");
		String url = sc.nextLine();
		Runtime rt = Runtime.getRuntime();
		String chrome = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe";
		rt.exec(chrome + " " + url);
	}
}

public class Ex09 {
	public static void main(String[] args) throws Exception {
		Phone2 p1 = new Phone2();
		Phone2 p2 = new Phone2();
		
		p1.sendMessage(p2);
		
		SmartPhone2 p3 = new SmartPhone2();
		p3.sendMessage(p1);	// 스마트폰도 폰이므로, 전화끼리 메시지를 주고받을 수 있다
		p3.web();
		
	}
}
