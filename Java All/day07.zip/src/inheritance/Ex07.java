package inheritance;

class Phone {
	void call() {
		System.out.println("다이얼을 돌려서 전화 통화를 합니다");
	}
}

class SmartPhone extends Phone {
	void web() {
		System.out.println("스마트폰은 웹 서핑을 할 수 있습니다");
	}
	// 물려받은 기능의 형식은 유지하면서 내용은 변경할 수 있다 (메서드 오버라이딩)
	void call() {
		System.out.println("즐겨찾기에 등록된 친구에게 전화통화를 합니다");
	}
}

public class Ex07 {
	public static void main(String[] args) {
		Phone ob1 = new Phone();
		SmartPhone ob2 = new SmartPhone();
		ob1.call();
		ob2.call();
		ob2.web();
	}
}
