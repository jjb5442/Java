package inheritance;

class Book {
	private String name;		// 책 이름
	private String date;		// 출판 일자
	private String publisher;	// 출판사
	private int price;			// 가격
	
	public Book(String name, String date, String publisher, int price) {
		super();
		this.name = name;
		this.date = date;
		this.publisher = publisher;
		this.price = price;
	}
	
	public void show() {
		System.out.printf("%s, %s, %s, %,d원\n", name, date, publisher, price);
	}
	
	@Override
	public String toString() {
		String data = String.format("%s : %,d원", name, price);
		return data;
	}
}

public class Ex11 {
	public static void main(String[] args) {
		Book[] arr = {
			new Book("작별인사", "2022-04-29", "복복서가", 12600),	
			new Book("법 만드는 아이들", "2022-04-29", "한국경제신문", 12600),	
			new Book("올림포스 연대기", "2022-04-29", "한빛비즈", 16200),	
		};
		
		for(int i = 0; i < arr.length; i++) {
//			arr[i].show();
			System.out.println(arr[i]);
//			System.out.println(arr[i].toString());
		}
	}
}
