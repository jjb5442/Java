package inheritance;

// 2차원의 좌표를 표현할 수 있는 클래스 Pos2D
class Pos2D {	// 상속관계에서 상속해주는 클래스, 상위 클래스, 슈퍼 클래스
	int x;
	int y;
	
	Pos2D(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	void show() {
		System.out.println("x : " + x);
		System.out.println("y : " + y);
		System.out.println();
	}
}

// 3차원의 좌표를 표현할 수 있는 클래스 Pos3D 
class Pos3D extends Pos2D {	// 상속관계에서 상속받는 클래스, 하위 클래스, 서브 클래스
//	int x;
//	int y;
	int z;
	
	// 1) 서브 클래스는 슈퍼 클래스의 생성자를 호출할 수 있어야 한다
	Pos3D(int x, int y, int z) {
		super(x, y);
//		this.x = x;	// 내가 필드를 만들지 않았지만 상속받아서 가지고 있다
//		this.y = y;	// 전달받은 x, y, z 중에서 x, y는 슈퍼클래스 생성자가 처리해주고
		this.z = z;	// Pos3D에서 만든 필드 z에 대해서만 처리해주면 된다
	}
	
	// 2) 상속받은 메서드는 형식 그대로 유지하면 내용만 바꿀 수 있다 (함수 덮어쓰기, 내용만 재정의하기)
	void show() {
		System.out.println("x : " + x);
		System.out.println("y : " + y);
		System.out.println("z : " + z);
		System.out.println();
	}
}


public class Ex08 {
	public static void main(String[] args) {
		Pos2D ob1 = new Pos2D(3, 7);
		ob1.show();
		
		Pos3D ob2 = new Pos3D(2, 5, 4);
		ob2.show();
	}
}
