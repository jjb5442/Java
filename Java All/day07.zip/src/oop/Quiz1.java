package oop;

import java.util.Arrays;
import java.util.Random;

class Student {
	// 아래 클래스의 구성요소에 접근제한자를 적용하고, 각각의 getter, setter를 만드세요
	// 멤버 필드 -> private, 멤버 메서드 -> public, 생성자 -> public
	// 저장 -> 우클릭 -> source -> generate getters and setters -> select all -> generate
	private String name;
	private int kor, eng, mat, sum;
	private double avg;
	
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMat() {
		return mat;
	}
	public void setMat(int mat) {
		this.mat = mat;
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public double getAvg() {
		return avg;
	}
	public void setAvg(double avg) {
		this.avg = avg;
	}
	
}

public class Quiz1 {
	public static void main(String[] args) {
		Student st = new Student();	// Student의 객체 생성
		
		// setter 를 이용하여 객체의 속성값을 대입
		st.setName("이지은");
		st.setKor(100);
		st.setEng(99);
		st.setMat(87);
		st.setSum(100 + 99 + 87);
		st.setAvg((100 + 99 + 87) / 3.0);
		
		// 접근제한자를 적용하지 않았을 때의 출력 양식
//		String format = "%s : %d, %d, %d \t (%d, %.2f)\n";
//		System.out.printf(format, st.name, st.kor, st.eng, st.mat, st.sum, st.avg);
		
		// 접근제한자를 적용한 이후 값을 지정하여 넣고
		// 화면에 위와 같은 형식으로 출력해보세요
		String format = "%s : %d, %d, %d \t (%d, %.2f)\n";
		System.out.printf(format, st.getName(), st.getKor(), st.getEng(), st.getMat(),
				st.getSum(), st.getAvg());
		
		System.out.println("-------------------------------------------");
		
		Student2 st2 = new Student2();
		Random ran = new Random();
		for(int i = 0; i < st2.scores.length; i++) {
			st2.scores[i] = ran.nextInt(100) + 1;
			st2.sum += st2.scores[i];
		}
		st2.avg = st2.sum / (double) st2.scores.length;
		
		System.out.printf("%d / %.2f\n", st2.sum, st2.avg);
		System.out.println(Arrays.toString(st2.scores));
	}
}

class Student2 {
	String name;
	int[] scores = new int[100];
	int sum;
	double avg;
}




