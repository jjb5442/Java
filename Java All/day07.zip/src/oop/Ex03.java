package oop;

// static : 객체마다 서로 다른 값을 가지지 않고, 클래스 자체에 연결된 속성 값
// 하나의 클래스로 여러 객체를 생성하면 객체마다 서로 다른 값을 가지게 된다
// 하지만 static 속성을 가지는 요소는 객체마다 서로 다른 값을 가지지 않고, 모두 같은 값을 가진다 (공유값)
// 여러 사람이 있다면, 사람 마다 이름이나 나이의 속성은 모두 다르겠지만
// 특정 사람이 아니라, '사람'이라는 자료형 만으로도 공통적으로 지정된 내용도 존재한다
// 예를 들어 특수한 경우를 제외하고, 모든 사람의 눈은 2개이며, 특정 사람을 가리키지 않아도 알수 있다
// 이런 정보는 객체에 속하는 값이 아니라 자료형(클래스)에 속하는 값이며 이런 값을 표현하기 위해 static을 사용한다

class Human2 {
	String name;
	int age;
	static int eyeCount = 2;
	
	public Human2(String name, int age) {
		this.name = name;
		this.age = age;
	}
	void show() {
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println();
	}
	void show2() {
		System.out.printf("%s의 눈은 %d개이다\n", name, eyeCount);
	}
}
public class Ex03 {
	public static void main(String[] args) {
		Human2 ob1 = new Human2("이지은", 30); 
		Human2 ob2 = new Human2("천진반", 20);
		ob1.show();
		ob2.show();
		
//		ob2.eyeCount = 3;	// 객체마다 가지는 값이 아니고
		Human2.eyeCount = 2;// 클래스에 소속된 값이기 때문에 클래스.필드 형식으로 접근해야 한다
		
		ob1.show2();
		ob2.show2();
	}
}
