package oop;

class Member {
	String name;
	int age;
	
	static int instanceCount = 0;
	
	Member(String name, int age) {	// 객체를 생성할 때 마다
		this.name = name;
		this.age = age;
		instanceCount++;			// instanceCount가 1증가한다
	}
	void show() {
		System.out.printf("%s : %d\n", name, age);
	}
	static void showInstanceCount() {
		System.out.println("생성된 총 객체의 개수 : " + instanceCount);
//		System.out.println(name); 	// static 메서드는 static 필드의 값만 참조할 수 있다
	}
}


public class Ex04 {
	public static void main(String[] args) {
		Member.showInstanceCount();	// 객체에 속한 함수가 아니므로, 객체 생성 없이도 클래스로 호출 가능
		
		Member ob1 = new Member("이지은", 30);
		Member ob2 = new Member("홍진호", 41);
		
		Member.showInstanceCount();
		
		Member ob3 = new Member("나단비", 5);
		
		Member.showInstanceCount();
		
		ob1.show();
		ob2.show();
		ob3.show();
		
	}
}
