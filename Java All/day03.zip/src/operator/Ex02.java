package operator;

import java.util.Scanner;

public class Ex02 {
	public static void main(String[] args) {
//		관계 연산자 : 크다(초과), 작다(미만), 크거나 같다(이상), 작거나 같다(이하), 일치, 불일치
		int n1 = 10;
		int n2 = 3;		// 코드가 실행되기 전에 이미 값이 결정되어 있다
		
		System.out.printf("%d >  %d : %b\n", n1, n2, n1 > n2);
		System.out.printf("%d >= %d : %b\n", n1, n2, n1 >= n2);
		System.out.printf("%d <  %d : %b\n", n1, n2, n1 < n2);
		System.out.printf("%d <= %d : %b\n", n1, n2, n1 <= n2);
		System.out.printf("%d == %d : %b\n", n1, n2, n1 == n2);
		System.out.printf("%d != %d : %b\n", n1, n2, n1 != n2);
		System.out.println();
		
		Scanner sc = new Scanner(System.in);
		
		String name, adult;	
		int age;	// 코드 실행중에 값이 결정된다
		
		System.out.print("이름 입력 : ");
		name = sc.next();
		System.out.print("나이 입력 : ");
		age = sc.nextInt();
		
		if(age >= 20) {		// 조건문의 조건으로 많이 사용되는 연산자이다
			adult = "성인";
		}
		else {
			adult = "미성년자";
		}
		System.out.printf("%s는 %d살이고, %s입니다\n", name, age, adult);
		sc.close();
		
		
		
		
		
	}
}
