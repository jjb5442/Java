package operator;

public class Ex07 {
	public static void main(String[] args) {
		// 간단한 비트 연산자의 활용
		
		int num = 4;		// 0100(2)
		
		int n1 = num << 1;	// 1000(2)	
		int n2 = num >> 1;	// 0010(2)
		
		System.out.println(n1);	// 왼쪽으로 비트를 한 칸 밀면 * 2와 같다
		System.out.println(n2);	// 오른쪽으로 비트를 한 칸 밀면 / 2와 같다
		
		if(num % 2 == 0) {
			System.out.println(num << 1);
		}
		else {
			System.out.println(num);
		}
		// 4 * 2를 수행하려면
		// 4는 2진수로 변환하면 0100
		// 2는 2진수로 변환하면 0010
		// 4 * 2 = 8 => 1000
		// 비트 시프트 연산으로 처리하면 처리 속도가 약간 빠를 수 있다
	}
}
