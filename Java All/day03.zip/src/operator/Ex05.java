package operator;

import java.util.Scanner;

public class Ex05 {
	public static void main(String[] args) {
		// 논리 연산
		// 1) A && B : A도 true이고, 동시에 B도 true이면 결과가 true
		// 2) A || B : A가 true이거나 혹은 B가 true이면 결과가 true
		// 3) !A : A가 true이면 결과는 false, A가 false이면 결과는 true
		
		Scanner sc = new Scanner(System.in);
		
		// 서로 다른 조건을 동시에 만족해야 하는 경우
		// 여성부 복싱 (체급 50kg ~ 56kg)
		int gender, weight;
		System.out.print("성별 (1. 남성, 2. 여성): ");
		gender = sc.nextInt();
		
		System.out.print("체중 입력 (kg): ");
		weight = sc.nextInt();
		
		boolean canPlay = (gender % 2 == 0) && (50 <= weight && weight <= 56);
		// 성별이 여성인가(숫자가 짝수인가)
		// 체중이 50이상인가 && 체중이 56이하인가
		// 성별이 여성이고, 체중이 범위 내에 포함되는가
		System.out.println("출전 가능 여부 : " + canPlay);
		System.out.println();
		
		
		// 택시타고 이동해야 하는 경우 (현금 혹은 결제 가능한 카드 둘중 하나라도 있다면 가능)
		// 예상 택시 비용 : 7000
		int cash, card;
		System.out.print("현금 보유 금액 : ");
		cash = sc.nextInt();
		
		System.out.print("카드 결제 가능 금액 : ");
		card = sc.nextInt();
		
		boolean canTakeTaxi = (cash >= 7000) || (card >= 7000);
		System.out.println("택시 사용 가능 여부 : " + canTakeTaxi);
		sc.close();
		
		int num = 54;
		// 값이 홀수가 아니라면 2로 나누어서 출력
		boolean isOddNum = num % 2 != 0;	// num의 값이 홀수인가
		
		if(isOddNum == false) {	// 조건이 거짓이면 (명확하게 나타내고 싶으면 이렇게)
			System.out.println(num / 2);
		}
		else {
			System.out.println(num);
		}
		
		if(!isOddNum) { 		// 논리 반전 (간결하게 적고 싶으면 이렇게, not)
			System.out.println(num / 2);
		}
		else {
			System.out.println(num);
		}
		
		
		
		
		
		
		
		
		
		
		
	}
}
