package operator;

import java.util.Scanner;

public class Ex01 {
	public static void main(String[] args) {
		// 연산자 : 데이터를 계산해서 새로운 값을 만들어 낼 수 있는 기호 집합 (단어포함)
		
		// 1) 산술 연산자 : +, -, *, /, %
		// - 산술 연산자를 이용할 때 정수와 정수를 연산하면 결과는 정수형으로 나타난다
		// - 산술 연산자를 이용할 때 정수와 실수를 연산하면 결과는 실수형으로 나타난다
		// - 산술 연산자를 이용할 때 수와 문자열을 연산할 경우 덧셈만 가능하며, 이어붙이기로 처리한다
		
		System.out.println(10 / 3);
		System.out.println(10 / 3.0);
		System.out.println(10 + "20");
		
		// %, 나머지 연산은 다음 경우에 사용할 수 있다
		// - 홀수/짝수, 약수/배수 를 구하고 싶을 때 사용한다 (나누어 떨어지는지 아닌지 판별)
		// - 정수의 자릿수를 구분하여 분리할 수 있다 (10^n으로 나눈 나머지)
		// - 난수(랜덤)의 범위를 조절할 수 있다
		
		System.out.println("3은 2로 나누어떨어지는가 : " + (3 % 2 == 0));
		System.out.println("4는 2로 나누어떨어지는가 : " + (4 % 2 == 0));
		System.out.println();
		System.out.println("1234에서 앞의 두자리만 분리하면 : " + (1234 / 100));
		System.out.println("1234에서 뒤의 두자리만 분리하면 : " + (1234 % 100));
		System.out.println();
		
		Scanner sc = new Scanner(System.in);
		System.out.print("임의의 수를 입력하세요 : ");
		int num = sc.nextInt();
		int dice = num % 6 + 1;	// 어떤 수를 6으로 나눈 나머지는 항상 6보다 작다
		System.out.println("주사위 값 : " + dice);
		System.out.println();
		sc.close();
		
		
		
		
		
		
	}
}
