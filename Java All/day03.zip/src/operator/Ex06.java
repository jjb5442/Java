package operator;

public class Ex06 {
	public static void main(String[] args) {
		
		// 삼항 연산자 : 조건에 따라 서로 다른 값을 결정한다
		// on/off, login/logout, 앞/뒤 처럼 선택지가 단 두가지만 있는 경우 주로 사용한다
		
		// 1) 조건에 따라 서로 다른 값을 변수에 저장한다
		int num = 5;
		String status = num % 2 == 0 ? "짝수" : "홀수";
		System.out.println("num은 " + status + "이다");
		
		// 2) 조건에 따라 서로 다른 값을 출력한다
		System.out.println(num % 2 == 0 ? "짝수" : "홀수");
		
		
	}
}
