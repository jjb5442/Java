package operator;

import java.util.Scanner;

public class Ex03 {
	public static void main(String[] args) {
		// 단항 연산자 : 하나의 항에 대해서 연산자를 사용하는 형식
		// 부호 제어와 증감 연산으로 구분할 수 있다
		
		// 1) 부호를 이용하여 절대값 구하기
		Scanner sc = new Scanner(System.in);
		int num, abs;
		System.out.print("아무 정수나 입력 : ");
		num = sc.nextInt();
		
		if(num < 0) {		// 만약, num의 값이 0보다 작으면
			abs = -num;		// num의 부호를 반전시킨 값을 abs에 저장
		}
		else {				// 아니라면,
			abs = num;		// abs에 num의 값을 그대로 대입한다
		}
		System.out.printf("%d의 절대값은 %d입니다\n", num, abs);
		sc.close();
		
		// 2) 증감연산자
		
		int num2 = 10;
		System.out.println();
		
		System.out.println(num2++);	// 먼저 출력하고 [나중에 값을 증가]	: 10 -> 출력 -> 11
		System.out.println(++num2);	// [먼저 증가하고] 나중에 값을 출력 	: 11 -> 12 -> 출력
		System.out.println(--num2);	// [먼저 감소하고] 나중에 값을 출력	: 12 -> 11 -> 출력
		System.out.println(num2--);	// 먼저 출력하고 [나중에 값을 감소]	: 11 -> 출력 -> 10
		
	}
}
