package operator;

public class Ex04 {
	public static void main(String[] args) {
		// 대입 연산자 : 오른쪽의 값을 왼쪽의 공간에 복사하여 저장한다
		int a = 10;		// 10을 a변수에 저장
		int b = a + 2;	// a의 값에 2를 더한 값을 b변수에 저장
		
		a = a + 3;		// a의 값에 3을 더한 값을 a변수에 저장
		
		int c = (a * 2) + (b + 1) / 2;
//				(13 * 2) + ((12 + 1) / 2) = 32
		
		System.out.println("a : " + a);
		System.out.println("b : " + b);
		System.out.println("c : " + c);
		
		// 배정(복합) 대입 연산자
//		a = a + 3;
		a += 3;		// 기존의 a값에 3을 더해서 새로 a에 저장한다
		System.out.println("a : " + a);
		
		for(int i = 0; i < 10; i += 2) {	// 기존 i의 값에 2를 누적합산한다
			System.out.println("i : " + i);
		}
		
	}
}
