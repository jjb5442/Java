package control;

public class Ex10 {
	public static void main(String[] args) {
		// if ~ else if ~ else : 여러 구문 중 하나만 실행해야 하는 경우
		// 5개의 보기 중 하나만 정답을 고르세요
		
		int num = 0;
		
		if(num > 0) {
			System.out.println("양의 정수");
		}
		else if(num < 0) {	// else 는 "아니면" 이라는 의미로 사용한다 
			System.out.println("음의 정수");
		}
		else {	// else 단독이면 조건을 따로 가지지 않는다 (이전의 조건이 모두 거짓이면 실행)
			System.out.println("num 은 0");
		}
	}
}
