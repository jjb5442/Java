package control;

import java.util.Scanner;

public class Quiz3 {
	public static void main(String[] args) {
		// 놀이기구 이용시간을 입력받아서 요금을 계산하여 출력하세요
		// 30분까지는 기본 요금 3천원을 적용하고 이후 10분씩 증가할 때 마다 추가요금 500원이 발생합니다
		// 요금표는 아래와 같습니다

		// 시간(분)	금액
		//  0 ~ 30	3,000원
		// 31 ~ 40	3,500원
		// 41 ~ 50	4,000원
		// 51 ~ 60	4,500원
		// ... (이후로도 같은 규칙 적용)
		
		int time, fee = 0;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("이용 시간 (분) : ");
		time = sc.nextInt();
		
		if(0 <= time && time <= 30) {	// 기본 요금
			fee = 3000;
		}
		else {							// 추가요금 발생
			fee = 3000 + (((time - 30) / 10 + 1) * 500);
			// 추가 시간이 발생했을 때 기본적인 식은 구했으나, 특정 상황에 따라 요금이 오차가 발생한다
			
		}
		
		System.out.printf("요금 : %,d원\n", fee);
		sc.close();
	}
}
