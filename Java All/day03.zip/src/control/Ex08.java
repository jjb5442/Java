package control;

public class Ex08 {
	public static void main(String[] args) {
		// 제어문 : 프로그램의 흐름을 나누거나, 반복, 제어하는 구문
		// 순서대로 실행되는 여러 구문의 실행 순서를 제어하는 문법
		
		// 1) 분기문 : 조건에 따라서 서로 다른 구문을 실행, if, switch ~ case
		// 2) 반복문 : 조건에 따라서 일정 코드를 반복하여 수행한다 : while, for
		// 3) 기타 제어문 : 조건에 상관없이 특정 줄로 이동한다 
		// break : 제어문 범위 블럭 {} 아래로 빠져나간다 
		// continue : 제어문 범위 블럭 {} 아래로 빠져나간다
		// return : 함수 범위 블럭 아래로 빠져나간다 (함수의 종료)
		
	}
}
