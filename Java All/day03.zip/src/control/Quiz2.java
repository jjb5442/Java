package control;

import java.util.Scanner;

public class Quiz2 {
	public static void main(String[] args) {	// 변수 추가 선언해서 사용 가능합니다
		Scanner sc = new Scanner(System.in);
		
		// 1) 두 정수를 변수 n1, n2에 입력받고 두 수중 값이 큰 수를 찾아서 출력하세요
		int n1, n2;
		System.out.print("두 정수를 입력 : "); 	// 띄워쓰기로 구분하여 입력 가능
		n1 = sc.nextInt();	// sc를 이용하여 정수를 하나 가져오고 그 값을 n1변수에 저장
		n2 = sc.nextInt();
		
		if(n1 > n2) {
			System.out.printf("%d가 %d보다 큽니다\n", n1, n2);
		}
		else {
			System.out.printf("%d가 %d보다 큽니다\n", n2, n1);
		}
		
		// 2) 세 정수를 변수 n3, n4, n5 에 입력받고, 세 정수중 값이 가장 작은 수를 찾아서 출력하세요
		int n3, n4, n5, min;
		System.out.print("세 정수를 띄워쓰기로 구분하여 입력 : ");
		n3 = sc.nextInt();
		n4 = sc.nextInt();
		n5 = sc.nextInt();
		
		min = n3;		// n3가 가장 작은 값이라고 가정하고 시작
		if(min > n4) {	// 현재 최소값이 n4보다 크면 (n4가 더 작은 값이면)
			min = n4;	// n4의 값을 최소값에 저장
		}
		if(min > n5) {
			min = n5;
		}
		System.out.printf("%d, %d, %d중 가장 작은 수는 %d입니다\n", n3, n4, n5, min);
		
		
		// 3) 정수를 n6에 입력받아서, 정수가 3의 배수인지 7의 배수인지 3과 7의 공배수인지 출력하세요
		int n6;
		// 여러 조건이 있을때, 여러 조건 중 하나만 처리해야 한다면 조건간의 우선순위를 판별해야 한다
		System.out.print("정수 입력 : ");
		n6 = sc.nextInt();
		
		if(n6 % 3 == 0 && n6 % 7 == 0)			// 조건 절, 문장이 아직 끝난것이 아님
			System.out.println("3과 7의 공배수");
		else if(n6 % 7 == 0) 	System.out.println("7의 배수");
		else if(n6 % 3 == 0) 	System.out.println("3의 배수");
		else 					System.out.println("해당없음");
		
		
		// 4) 두 정수를 n7, n8에 입력받고 두 수의 합을 n9에 입력받아서 정답인지 아닌지 출력하세요
		int n7, n8, n9;
		String result;
		System.out.print("두 정수 입력 : ");
		n7 = sc.nextInt();
		n8 = sc.nextInt();
		System.out.print("두 정수의 합을 입력 : ");
		n9 = sc.nextInt();
		
		// 분기문 내에서 변수의 값만 지정하고, 분기문이 끝났을때 이후에 값을 출력하는 형태로 사용
		if(n9 == n7 + n8) 	result = "정답";
		else 				result = "오답";
		
		System.out.println(result);
		// 위 식은 정답 혹은 오답 2가지의 경우의 수만 존재하므로, 삼항 연산자로 처리할 수도 있다
		
		sc.close();
		
		
	}
}
