package control;

public class Ex09 {
	public static void main(String[] args) {
		// if : 조건이 참이면 종속 문장을 실행한다
		
		int num = 30;
		
		if(num < 20) {	// 조건이 참이면 실행하고, 거짓이면 실행하지 않는다
			System.out.println(++num);
		}
		
//		if(num >= 20) {	// 이전에 작성된 if의 조건과 반대되는 조건을 가진다면 else로 변경할 수 있다
		else {
			System.out.println(--num);
		}
	}
}
