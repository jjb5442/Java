package control;

public class Ex12 {
	public static void main(String[] args) {
		// 제어문 내부에 또다른 제어문을 사용할 수도 있다
		// if 안에 또다른 if가 있으면 두 조건을 모두 만족할 경우에만 실행한다 (and 연산과 유사함)
		
		int num = 12;
		
		if(num % 3 == 0) {
			if(num % 4 == 0) {
				System.out.printf("%d는 3의 배수이며 4의 배수이다\n", num);
			}
		}
		
		if(num % 3 == 0 && num % 4 == 0) {
			System.out.printf("%d는 3과 4의 공배수이다\n", num);
		}
	}
}
