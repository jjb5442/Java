package control;

public class Ex11 {
	public static void main(String[] args) {
		// if ~ if ~ if : 여러 구문 중 조건을 만족하는 구문을 모두 실행한다
		// 5개의 보기 중 정답인 것을 모두 고르세요
		int num = 12;
		
		if(num % 3 == 0) {
			System.out.printf("%d는 3의 배수이다\n", num);
		}
		if(num % 4 == 0) {
			System.out.printf("%d는 4의 배수이다\n", num);
		}
		if(num % 5 == 0) {
			System.out.printf("%d는 5의 배수이다\n", num);
		}
	}
}
