package oop;

class Circle {
	// 필드
	double radius;
	double length;
	double square;
	double pi = 3.14;
	
	// 생성자 (오버로딩)
	Circle() {
//		radius = 1;
//		length = 2 * radius * pi;
//		square = radius * radius * pi;
		this(1.0);				// Circle(double radius)
	}
	Circle(int radius) {
//		this.radius = radius;
//		length = 2 * radius * pi;
//		square = radius * radius * pi;
		this((double)radius);	// Circle(double radius)
	}
	Circle(double radius) {
		this.radius = radius;
		length = 2 * radius * pi;
		square = radius * radius * pi;
	}
	
	// 메서드
	void show() {
		System.out.printf("반지름 : %.2f, 둘레 : %.2f, 넓이 : %.2f\n", 
				radius, length, square);
	}
}

public class Quiz1 {
	public static void main(String[] args) {
//		원을 나타내는 객체를 생성하려고 한다
//		생성자 매개변수에는 반지름(radius)를 전달하여 객체를 생성할 수 있다
//		show() 메서드는 원의 반지름, 원의 둘레, 원의 넓이를 소수점 둘째자리까지 출력한다
//		클래스를 작성하고, 메인함수가 정상적으로 작동할 수 있도록 코드를 완성하세요
//		단, 생성자 매개변수가 없으면 반지름을 1로 처리하고, 원주율은 3.14 로 처리하세요
//		둘레 = 반지름 * 2 * 원주율		2πr
//		넓이 = 반지름 * 반지름 * 원주율	πr²
		
		Circle c1 = new Circle();		// 매개변수 없음
		Circle c2 = new Circle(3);		// 매개변수 int
		Circle c3 = new Circle(2.4);	// 매개변수 double
		
		c1.show();
		c2.show();
		c3.show();
	}
}
