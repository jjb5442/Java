package oop;

import java.util.Scanner;

public class Ex08 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] arr = { "이지은", "홍진호", "나단비", null, null, "임요환" };
		
		System.out.print("검색할 이름을 입력 : ");
		String name = sc.next();		// 사용자의 입력값
		String find = null;				// 프로그램에서 찾아낸 값을 저장할 변수
		
		for(int i = 0; i < arr.length; i++) {
			// 빈칸이 아니고, 값이 입력값과 일치하는 곳을 찾아서
			if(arr[i] != null && arr[i].equals(name)) {	// A.equals(B) : A와 B가 일치하는지 
				find = arr[i];	// 찾은 값을 find에 대입한다 (대입하면 더이상 null이 아니다)
				break;
			}
		}
		if(find != null) {	// 찾았다면 결과를 출력
			System.out.println("검색 결과 : " + find);
		}
		else {	// find가 여전히 null이라면 못찾았다는 의미
			System.out.println("일치하는 결과를 찾을 수 없습니다");
		}
		sc.close();
	}
}
