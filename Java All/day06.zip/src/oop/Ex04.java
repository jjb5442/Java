package oop;

public class Ex04 {
	public static void main(String[] args) {
		String[] name = { "코카콜라", "사이다", "포카리스웨트", "비타500" };
		int[] price = 	{ 800, 		700, 	 900,		  500	  };
		
		for(int i = 0; i < name.length; i++) {
			System.out.printf("%s : %,d원\n", name[i], price[i]);
		} System.out.println();
		
		// 정렬
		for(int i = 0; i < name.length; i++) {
			for(int j = i; j < name.length; j++) {
				if(price[i] > price[j]) {
					int tmp = price[i];
					price[i] = price[j];
					price[j] = tmp;
					
					String tmp2 = name[i];
					name[i] = name[j];
					name[j] = tmp2;
				}
			}
		}
		// 속성값이 2개뿐이라면 2개만 교환하면 되지만, 속성값이 많다면 그 개수만큼 코드가 길어진다
		
		for(int i = 0; i < name.length; i++) {
			System.out.printf("%s : %,d원\n", name[i], price[i]);
		} System.out.println();
	}
}
