package oop;

class Car {
	// 클래스 : 객체를 생성하기 위한 자료형, 변수와 함수를 만들 수 있다
	// 객체 : 클래스 자료형에 의해 생성된 데이터, 같은 클래스의 여러 객체가 존재할 수 있다
	
	// 클래스는 다음 요소로 구성될 수 있다
	// 1) 멤버 필드 (변수) 	: 객체의 속성값을 저장하는 변수
	// 2) 멤버 메서드 (함수)	: 객체의 기능을 정의하는 함수
	// 3) 생성자 (함수) 	: 객체를 생성하고, 객체 생성 시 초기 작동을 정의하는 함수
	// 4) 접근제한자 		: 객체의 멤버 요소에 대한 외부로부터의 접근을 제어할 수 있는 예약어
	
	// 만약 자동차를 객체로 코드에서 표현하고 싶다면, 먼저 자동차가 어떻게 구성되어 있는지 정의한다
	// 속성 : 정적 데이터 (차종, 최대출력, 최대인원, 색상)
	// 기능 : 동적 코드 (가속한다. 감속한다. 방향전환한다. 문을 연다/닫는다. 라이트를 켠다/끈다)
	
	// 단, 클래스는 실제 데이터를 만들기 위한 설계도와 같은 개념이므로
	// 클래스를 이용하여 반드시 실제 객체를 만들고, 객체를 이용하여 코드를 진행해야 한다
}

class Character {	// 영화 및 드라마, 게임의 등장인물을 표현하기 위한 자료형
	String name;		// 작중 이름
	String actorName;	// 실제 배우 이름
	String gender;		// 성별
	String comment;		// 간단 소개글
	
	void show() {
		System.out.printf("%s (%s) : %s, %s\n", name, actorName, gender, comment);
	}
	
	// 생성자 : 객체를 생성하고, 객체 생성 후 초기작동을 정의하는 함수
	Character(String name, String actorName, String gender, String comment) {
		this.name = name;
		this.actorName = actorName;
		this.gender = gender;
		this.comment = comment;
	}
}

public class Ex02 {
	public static void main(String[] args) {
//		Character ch1 = new Character();
//		ch1.name = "닥터 스트레인지";
//		ch1.actorName = "베네딕트 컴버배치";
//		ch1.gender = "남성";
//		ch1.comment = "최강의 마법사";
		Character ch1 = new Character("닥터 스트레인지", "베네딕트 컴버배치", "남성", "최강의 마법사");
		
//		Character ch2 = new Character();
//		ch2.name = "완다 막시모프";
//		ch2.actorName = "엘리자베스 올슨";
//		ch2.gender = "여성";
//		ch2.comment = "스칼렛 위치";
		Character ch2 = new Character("완다 막시모프", "엘리자베스 올슨", "여성", "스칼렛 위치");
		
		ch1.show();
		ch2.show();
		
//		ch1과 ch2는 같은 자료형 (Character) 이므로, 같은 자료형의 여러 데이터는 배열로 묶어서 처리할 수 있다
//		만약 객체의 개수가 많다면, 개별 객체를 따로 제어하는 것보다, 배열형태로 묶어서 처리하는 것이 더 편하다
		
		Character[] arr = { ch1, ch2 };
		for(int i = 0; i < arr.length; i++) {
			arr[i].show();	// 객체에 담긴 정보를 일정한 형태로 화면에 출력하는 기능
		}
		
	}
}





