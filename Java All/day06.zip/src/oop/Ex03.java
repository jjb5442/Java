package oop;

class Drink {		// 자판기에 사용되는 음료수의 형태를 정의
	
	// 1) 멤버 필드, 객체의 속성을 저장하는 변수. 
	// 별도의 초기값이 없으면 0에 해당하는 값으로 자동으로 초기화
	// 클래스는 하나이지만, 하나의 클래스로 여러개의 객체를 생성할 수 있기 때문에
	// 객체마다 서로 다른 값을 가질 수 있어야 한다 (초기값을 미리 주면 모든 객체가 같은 값을 가진다)
	String name; // = null;		// 음료수의 이름
	int price;	 // = 0;		// 음료수의 가격
	
	// 2) 멤버 메서드, 객체의 기능을 정의하는 함수.
	// 함수 내에서 변수 선언, 연산, 제어문, 다른 함수 호출 등 대부분의 코드를 작성할 수 있다
	// 메서드 안에서는 별도의 조건 없이 멤버 필드를 참조할 수 있다
	void show() {
		String msg = "음료수 정보) ";	// 함수 내부의 지역변수
		System.out.printf(msg + "%s : %,d원\n", name, price);
	}
	void init(String name, int price) {
		// 함수 안에서 지정한 이름의 변수(지역변수, 매개변수)가 있으면
		// 지역변수를 먼저 참조한다
		// 만약 이름이 같은데 멤버 필드를 참조하고 싶으면 앞에 this.을 붙인다
		this.name = name;	// 매개변수로 전달받은 name의 값을 멤버 필드에 저장한다
		this.price = price;
	}
}

public class Ex03 {
	public static void main(String[] args) {
		Drink d1 = new Drink();
		d1.name = "코카콜라";
		d1.price = 800;
//		d1.show();
		
		Drink d2 = new Drink();
		d2.init("사이다", 700);		// 객체에 값을 넣어주는 함수			(입력)
//		d2.show();					// 객체에 담긴 값을 화면에 출력하는 함수	(출력)
		
		Drink d3 = new Drink();
		d3.init("포카리스웨트", 900);
//		d3.show();
		
		Drink d4 = new Drink();	// 객체만 생성하면 값이 들어가있지 않다(빈 객체)
		d4.init("비타500", 500);
//		d4.show();
		
		// Drink타입의 객체가 여러개이므로, 배열로 묶어서 처리하면 좀 더 수월하다
		Drink[] arr = { d1, d2, d3, d4 };
		for(int i = 0; i < arr.length; i++) {
			Drink d = arr[i];	// 배열의 i번째 요소를 d라고 할때
			d.show();			// d객체의 show() 기능을 실행
		} System.out.println();
		
//		Drink d4 = new Drink(); 	생성자를 호출하면 새로운 객체를 생성한다
//		Drink d = arr[i];			생성자 호출이 없으니, 기존 객체를 변수에 저장만 한다
		
//		Drink d5;	// The local variable d5 may not have been initialized
//		d5.name = "비타500";
		// 지역 변수 d5가 초기화되지 않아서 사용할 수 없습니다
		
		
		// 선택정렬을 이용하여 음료수를 가격순으로 정렬하기
		for(int i = 0; i < arr.length; i++) {
			for(int j = i; j < arr.length; j++) {
				if(arr[i].price > arr[j].price) {
					Drink tmp = arr[i];	// tmp는 객체 생성이 아니고, 잠시 받아주는 임시 변수
					arr[i] = arr[j];	// tmp 선언문에는 생성자 호출이 없다
					arr[j] = tmp;		// 생성자 호출이 없으면 객체 생성이 아니다
				}
			}
		}
		
		for(int i = 0; i < arr.length; i++) {
			arr[i].show();
		}
		
		// Ex03 코드에서는 객체를 활용하여 데이터를 표현하기 때문에
		// 가격기준으로 정렬하면 음료수의 이름도 같이 움직인다
		// 만약 클래스와 객체 없이 배열만으로 정렬하면 어떻게 되는지 Ex04에서 작성해봅니다
	}
}
