package oop;

class Pos {
	// 필드
	int x;
	int y;
	
	// 메서드
	void showPos() {
		System.out.println("x : " + x);
		System.out.println("y : " + y);
		System.out.println();
	}
	
	// 생성자 (정수 2개를 받아서 각각 x와 y에 대입하는 기능 포함)
	Pos(int x, int y) {
		this.x = x;
		this.y = y;
		// 매개변수를 받는 생성자를 작성했기 때문에, 자동으로 기본생성자가 만들어지지 않는다
		// 기본 생성자 없이 매개변수 받는 생성자만 있다면
		// Pos 타입의 객체를 생성하기 위해서는 반드시 정수 2개를 전달해야 한다
	}
	Pos() {
		// 생성자 내부에서 또다른 생성자를 호출
		// 매개변수를 전달받지 않으면 기본값을 0, 0이 아니라 1, -1로 하고 싶다면
//		Pos(1, -1);	// 생성자 이름으로 호출하는 것은 클래스 외부에서만 가능하다
		this(1, -1);// this는 자기자신을 의미하므로, 자신과 같은 이름의 함수 == 생성자
		System.out.println("기본 생성자 호출 !!");
		
		// 생성자 내부에서 다른 생성자를 호출하는 것은 첫번째 줄에서만 가능하다
		// 클래스를 본따서 객체를 생성 -> 추가작업 진행
	}
}

public class Ex06 {
	public static void main(String[] args) {
		Pos ob1 = new Pos(2, 3);	// 객체를 생성하면서 초기값을 지정할 수 있다
		ob1.showPos();
		
		Pos ob2 = new Pos(11, 7);	// 객체마다 서로 다른 값을 가지게 할 수 있다
		ob2.showPos();
		
		Pos ob3 = new Pos();
		ob3.showPos();
	}
}
