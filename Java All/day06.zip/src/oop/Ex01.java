package oop;

public class Ex01 {
//	어떤 유형의 데이터를 어떤 방식으로 처리할 것인가
//	[자료형]			[함수]
//	단일변수			정의, 호출
//	배열				연산자, 제어문
//	클래스 : 서로 다른 자료형의 여러 변수와 함수를 묶어서 만든 사용자 정의 자료형
//	String str;
//	Scanner sc;
	
	public static void main(String[] args) {	
		// 1) 클래스를 사용하지 않고, 원하는 유형의 변수를 사용하여 데이터를 처리
		// 학생 1명당, 이름, 국어, 영어, 수학, 합계, 평균등을 모두 별개로 처리하면
		// 변수가 많아지고, 관리가 어려워진다 (각 변수의 자료형이 서로 다르다)
		String name = "이지은";
		int kor = 100, eng = 99, mat = 87;
		int sum = kor + eng + mat;
		double avg = sum / 3.0;
		
		System.out.printf("%s의 합계는 %d점이고, 평균은 %.2f점입니다\n\n",
				name, sum, avg);
		
		// 2) 학생 자료형을 클래스로 만들어두고 클래스를 이용하여 생성한 객체로 처리하기
		// st변수(가 가리키는 객체)에 관련된 모든 정보가 들어 있다 
		// 해당 자료형의 데이터가 자체적으로 가지는 기능도 포함시킬 수 있다
		// 특정 자료형과 상호작용하는 함수는, 그 자료형과 함께 사용해야 한다
		Student st = new Student();
		st.name = "이지은";
		st.kor = 100;
		st.eng = 99;
		st.mat = 87;
		st.sum = st.kor + st.eng + st.mat;
		st.avg = st.sum / 3.0;
		st.show();
		
		// 3) 클래스의 문법을 활용하면 위 코드를 훨씬 편하게 사용할 수 있다
//		Student st2 = new Student("이지은", 100, 99, 87);
//		st2.show();
		
//		자바에서 객체를 생성하는 기본적인 형식
//		클래스 변수이름 = new 클래스();
//		Student st = new Student();
		
//		Student 형태의 객체를 가리킬 수 있는 변수 st를 선언하고,
//		new 새로운 메모리 공간을 할당받아서 그 곳에 클래스에 작성된대로 객체를 생성하고
//		생성된 객체의 메모리 주소를 st변수에 저장해둔다
	}
} // end of class Ex01

class Student {
	// 변수
	String name;
	int kor, eng, mat, sum;
	double avg;
	
	// 함수
	void show() {
		System.out.printf("%s의 합계는 %d점이고, 평균은 %.2f점입니다\n\n",
				name, sum, avg);
	}
}




