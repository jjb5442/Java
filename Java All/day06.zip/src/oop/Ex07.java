package oop;

import java.util.Scanner;

// 어떤 자료형(Student2)을 어떤 방식(목록출력, 입력, 정렬)으로 처리할 것인가?

class Student2 {
	// 필드
	String name;
	int kor, eng, mat, sum;
	double avg;
	
	// 생성자
	Student2(String name, int kor, int eng, int mat) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.mat = mat;
		this.sum = kor + eng + mat;
		this.avg = sum / 3.0;
	}
	
	// 메서드
	void show() {
		System.out.printf("%s) %3d, %6.2f\n", name, sum, avg);
	}
}

public class Ex07 {
	public static void main(String[] args) {
//		기본적인 관리 프로그램 (목록, 추가, 검색, 수정, 삭제) 기능을 구현해보기
		
		Scanner sc = new Scanner(System.in);
		Student2[] arr = new Student2[10];	// 비어 있는 10칸 짜리 배열
		arr[0] = new Student2("이지은", 100, 99, 87);
		int menu;
		
		do {			// 최초 1번은 실행하고
			System.out.println("1. 목록");
			System.out.println("2. 추가");
			System.out.println("3. 정렬");	// 선택 정렬로 평균 기준 내림차순 정렬하기
			System.out.println("4. 검색");	// 이름이 일치하는 학생의 정보만 출력하기
			System.out.println("5. 삭제");	// 이름이 일치하는 학생의 변수에 null 대입하기
			System.out.println("0. 종료");
			System.out.print("선택 >>> ");
			menu = sc.nextInt();
			
			switch(menu) {
			case 1:		// 목록 출력
				for(int i = 0; i < arr.length; i++) {
					if(arr[i] != null) {	// null은 빈칸, 공간만 있고 객체가 없을 경우
						arr[i].show();
					}
				}
				break;
			case 2:		// 추가
				for(int i = 0; i < arr.length; i++) {
					if(arr[i] == null) {	// 빈칸이면 새로운 객체를 생성한다
						System.out.print("이름과 국영수 점수를 띄워쓰기로 구분하여 입력 : ");
						arr[i] = new Student2(sc.next(), sc.nextInt(), sc.nextInt(), sc.nextInt());
						break; 	// 빈칸 하나에 객체를 추가했다면 반복 중단
					}
				}
				break;	// case 2의 내용이 끝났으면 switch break
				
			case 3:		// 정렬
				for(int i = 0; i < arr.length; i++) {
					for(int j = i; j < arr.length; j++) {
						// 빈칸 학생의 평균을 확인할 수 없으니, 둘 다 null이 아닐 경우에만 정렬을 수행한다
						if(arr[i] != null && arr[j] != null) {
							if(arr[i].avg < arr[j].avg) {
								Student2 tmp = arr[i];
								arr[i] = arr[j];
								arr[j] = tmp;
							}
						}
					}
				}
				break;
			case 4:		// 검색
				// 검색할 이름을 입력받고
				System.out.print("검색할 학생의 이름 입력 : ");
				String name = sc.next();
				Student2 find = null;		// 찾은 학생을 저장해 둘 변수
				// 배열을 처음부터 순서대로 조회하면서
				for(int i = 0; i < arr.length; i++) {
					// null이 아니고, 입력받은 이름과 일치하는 객체를 찾으면
					if(arr[i] != null && name.equals(arr[i].name)) {
						// 해당 객체의 show() 함수를 호출하고 break 하면 끝
						find = arr[i];
//						arr[i].show();
						break;	// for에 대한 break
					}
				}
				if(find == null) {
					System.out.println("결과를 찾을 수 없습니다");
				}
				else {
					find.show();
				}
				break;	// switch ~ case 에 대한 break
				
			case 5:		// 삭제
				// 이름으로 검색하여 일치하는 학생이 있는지 확인한다
				// 만약 일치하는 학생을 찾았다면 (사용자에게 삭제할지 한 번 더 물어보고)
				// arr[i] = null;
				System.out.print("삭제할 학생의 이름 입력 : ");
				String deleteName = sc.next();	// 이름을 입력하여
				
				for(int i = 0; i < arr.length; i++) {
					if(arr[i] != null && arr[i].name.equals(deleteName)) {	// 일치하는 이름의 학생 찾기
						arr[i].show();
						System.out.print("이 학생의 정보를 삭제하시겠습니까?");
						String confirm = sc.next();
						if(confirm.equalsIgnoreCase("y")) {
							// A.equalsIgnoreCase(B) : A와 B의 내용이 대소문자 구분하지 않고 일치하는지 판단
							arr[i] = null;
						}
						break;
					}
				}
				break;
				

				// 다음주 토요일 7일차에 삭제 코드 확인하기 
			}
			
			System.out.println();
		} while(menu != 0);	// 조건에 따라 반복을 수행하는 구문
		sc.close();
		
	}
}










