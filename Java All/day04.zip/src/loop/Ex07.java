package loop;

import java.util.Scanner;

public class Ex07 {
	public static void main(String[] args) {
		// 무한반복 걸어두고 if를 이용하여 break 하는 예시
		// 사용자에게 정수를 입력받아서 정수를 자릿수 뒤집어서 변수에 저장하고 출력하기
		// 입력되는 정수의 자릿수를 미리 예측할 수 없다
		
		Scanner sc = new Scanner(System.in);
		int num, ret = 0;
		
		System.out.print("정수 입력 : ");
		num = sc.nextInt();
		
		System.out.print(num + "을 거꾸로 하면 ");
		
		while(true) {	// 반복을 얼마나 해야할지 미리 정할 수 없다
			ret += num % 10;	// num의 끝자리수를 ret에 더한다
			ret *= 10;			// ret에 10을 곱해서 1의 자리를 비워둔다
			num /= 10;			// ret에 더한 마지막 자리는 버린다
			if(num < 10) {		// num이 한자리수만 남는다면 (중단 조건)
				ret += num;		// 남은 한 자릿수만 ret에 더한 다음
				break;			// 반복을 중단한다
			}
		}
		System.out.println(ret);
		sc.close();
		
	}
}
