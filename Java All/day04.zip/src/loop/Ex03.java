package loop;

public class Ex03 {
	public static void main(String[] args) {
		// 반복문 : 조건에 따라 특정 코드를 반복하여 수행한다
		
		int num = 10;
		
		if(num < 20) {	// 조건이 참이면 종속문장을 한번 실행한다
			System.out.println("if) " + ++num);
		}
		
		while(num < 20) { // 조건이 참이면 종속문장을 반복하여 실행한다
			if(num == 19) {
				break;
			}
			System.out.println("while) " + ++num);
			// 종속문장이 끝난 후, 다시 조건을 확인하기 위해서 위로 올라간다
		}
	}
}
