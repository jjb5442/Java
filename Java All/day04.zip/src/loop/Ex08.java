package loop;

public class Ex08 {
	public static void main(String[] args) {
		// for : 일정 횟수에 의한 반복을 처리한다
		
		int cnt = 0;		// 1) 반복 횟수를 제어할 변수 선언 및 초기화
		while(cnt < 5) {	// 2) 반복 수행 조건
			System.out.println("Hello");	// 3) 반복문의 종속문장
			cnt++;			// 4) 반복 횟수의 증감
		}
		System.out.println();

//			(1)			(2)	   (4)
		for(int i = 0; i < 5; i++) {
			System.out.println("Hello");	// (3)
		} System.out.println();
//		1 -> 2 -> 3 -> 4 -> 2 -> 3 -> 4 -> 2 (조건이 거짓이면 종료)
	}
}


