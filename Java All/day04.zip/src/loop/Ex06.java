package loop;

import java.util.Random;
import java.util.Scanner;

public class Ex06 {
	public static void main(String[] args) {
		// while에 직접 조건을 걸어주는 예시
		Random ran = new Random();
		int answer = ran.nextInt(100) + 1;
		// 0부터 총 100개의 정수범위를 설정하고 그중 하나를 가져온다 (+1에 의해 범위는 1~100)
		
		Scanner sc = new Scanner(System.in);
		int input = 0;
		
		while(answer != input) {	// 정답과 입력값이 다르면 반복문을 실행
			System.out.print("정답을 맞춰보세요 : ");
			input = sc.nextInt();
			if(answer > input)  	System.out.println("UP");
			else if(answer < input)	System.out.println("DOWN");
		}
		System.out.println("정답 !!");
		sc.close();
//		while에 조건이 들어가있다면, if의 조건과 마찬가지로 생각하면 된다(반복되는 if)
	}
}
