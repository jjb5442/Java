package loop;

import java.util.Scanner;

public class Quiz4 {
	public static void main(String[] args) {
		// 1) 1부터 10까지의 합계 출력
		int n1 = 0;
		for(int i = 1; i <= 10; i++) {
			n1 += i;
		}
		System.out.println("1) 1부터 10까지의 합계 : " + n1);
		System.out.println();
		
		// 2) 11부터 20까지의 합계 출력
		int n2 = 0;
		for(int i = 11; i <= 20; i++) {
			n2 += i;
		}
		System.out.println("2) 11부터 20까지의 합계 : " + n2);
		System.out.println();
		
		// 3) 5부터 0까지 한 줄에 순서대로 출력
		System.out.print("3) 5부터 0까지 : ");
		for(int i = 5; i != -1; i--) {	// 증감식, 증가하거나 감소하거나
			System.out.print(i + " ");
		} System.out.println("\n");
		
		Scanner sc = new Scanner(System.in);
		// 4) 1부터 입력받은 정수까지의 합계 출력
		int n4, sum = 0;
		System.out.print("정수 입력 : ");
		n4 = sc.nextInt();
		
		System.out.printf("4) 1부터 %d까지의 합계 : ", n4);
		for(int i = 1; i <= n4; i++) {	// n4는 범위를 설정하기 위해서
			sum += i;	// i는 범위 내에서 변하는 수를 저장하는 변수
		} System.out.println(sum + "\n");
		
		
		// 5) 1부터 100사이의 정수 중에서 입력받은 정수의 배수만 한 줄에 출력
		// 조건을 설정하여 조건에 맞는 값만 처리
		
		int n5;
		System.out.print("정수 입력 : ");
		n5 = sc.nextInt();
		for(int i = 1; i <= 100; i++) {
			if(i % n5 == 0) {
				System.out.print(i + " ");
			}
		} System.out.println();
		
	}
}
