package loop;

public class Ex04 {
	public static void main(String[] args) {
		
		// while을 사용하는 패턴
		// 1) if처럼 만들어서 특정 조건을 만족할 경우에만 반복하기
		int cnt = 0;
		while(cnt != 5) {	// 변수의 값이 5가 아니면 반복한다
			System.out.println(cnt);
			cnt++;	// 이 형태를 다듬어서 다른 문법으로 나온것이 for문
		}
		
		// 2) while의 조건에 true를 넣어서 무한반복으로 만들어두고 
		// if에 의해서 탈출할 조건을 명시하고 break 걸어주기
		cnt = 0;
		while(true) {
			System.out.println(cnt);
			cnt++;
			if(cnt == 5) {	// 변수의 값이 5와 같으면 탈출한다
				break;
			}
		}
		
		System.out.println("종료");
	}
}
