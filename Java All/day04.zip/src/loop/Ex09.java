package loop;

public class Ex09 {
	public static void main(String[] args) {
		// 1) 1부터 100까지의 정수 합계 구하기
		int sum = 0;
		for(int i = 0; i < 101; i++) {
			sum += i;
		}
		System.out.println("1) 합계 : " + sum);
		System.out.println();
		
		// 2) 1부터 100사이의 정수 중 홀수의 합과 짝수의 합을 나누어 구하기
		int oddSum = 0, evenSum = 0;
		for(int i = 0; i < 101; i++) {
			if(i % 2 == 0) 	evenSum += i;
			else 			oddSum += i;
		}
		System.out.printf("2) 홀수의 합 : %d, 짝수의 합 : %d\n\n", oddSum, evenSum);
		
		// 3) 알파벳 A부터 Z까지 한줄에 출력하기
		System.out.println("3) 알파벳 출력");
		for(char ch = 'A'; ch <= 'Z'; ch++) {
			System.out.print(ch + " ");
		} System.out.println("\n");
	}
}
