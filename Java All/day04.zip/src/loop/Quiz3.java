package loop;

public class Quiz3 {
	public static void main(String[] args) {
		// 은행에 돈을 입금한다
		// 첫날은 10원, 둘째날은 20원, 셋째날은 40원, 이런 식으로 전날의 두배를 입금한다
		// 30일동안 입금했을 때 은행 계좌에 입금된 총 금액이 얼마인지 계산하여 출력하세요
		
		
	}
}
