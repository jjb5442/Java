package loop;

public class Quiz2 {
	public static void main(String[] args) {
		// 1) Hello, world 문자열을 3회 출력하세요
		// 반복하여 출력
		int cnt = 0;
		while(cnt != 3) {
			System.out.println("Hello, world");
			cnt++;
		}
		System.out.println();
		
		// 2) 1부터 10까지 정수를 띄워쓰기로 구분하여 한 줄에 출력하세요
		// 반복하여 출력
		cnt = 1;
		while(cnt != 11) {
			System.out.print(cnt + " ");
			cnt++;
		}
		System.out.println("\n");
		
		// 3) 1부터 100사이의 정수의 합을 구하여 출력하세요
		// 반복하여 덧셈연산 이후 한번만 출력
		int sum = 0;
		cnt = 1;
		while(cnt != 101) {
			sum += cnt;
			cnt++;
		}
		System.out.println("합계 : " + sum);
		System.out.println();
		
	}
}
