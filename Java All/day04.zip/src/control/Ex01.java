package control;

import java.util.Scanner;

public class Ex01 {
	public static void main(String[] args) {
		// switch ~ case
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 입력 : ");
		int num = sc.nextInt();
		
		if(num == 1) 		System.out.println(1);
		else if(num == 2) 	System.out.println(2);
		else if(num == 3) 	System.out.println(3);
		else 				System.out.println("1, 2, 3이 아닌 다른 숫자");
		
		// if문이 특정 변수의 값을 확인하는 코드라면, switch 문으로 바꿀 수 있다
		switch(num) {	// num의 값이 일치하는 case를 찾아서 해당 줄에서 시작한다
		case 1: System.out.println("입력한 값은 1"); break;	// break를 만나면 switch를 탈출
		case 2: System.out.println("입력한 값은 2"); break;
		case 3: System.out.println("입력한 값은 3"); break;
		default: System.out.println("다른 숫자");
		}
		sc.close();
		
	}
}
