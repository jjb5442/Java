package control;

import java.util.Scanner;

public class Ex02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		1) switch에는 정수 혹은 문자열이 올 수 있다 (실수는 사용할 수 없다)
		double db;
		System.out.print("실수 입력 : ");
		db = sc.nextDouble();
		
		switch((int)db) {
		case 1: 
			System.out.println("정수 범위의 1");
			break;
		case 2:
			System.out.println("정수 범위의 2");
			break;
		}
		System.out.println();
		
		String subject;
		System.out.print("과목 이름 입력 : ");
		subject = sc.next();
		
		switch(subject) {
		case "네트워크":
			System.out.println("네트워크 수업은 1101호입니다"); break;
		case "파이썬":
			System.out.println("파이썬 수업은 1102호입니다"); break;
		case "리눅스":
			System.out.println("리눅스 수업은 1103호 입니다"); break;
		case "자바":
			System.out.println("자바 수업은 1104호입니다"); break;
		case "자료구조":
			System.out.println("자료구조 수업은 1106호입니다"); break;
		default:	// default 혹은 마지막에 작성된 case는 break를 작성하지 않아도 된다
			System.out.println("입력 내용과 일치하는 강의장을 찾을 수 없습니다");
		}
		System.out.println();
		
//		2) switch에는 반환값이 있는 함수, 혹은 연산식이 들어갈 수 있다
		int num;
		System.out.print("정수 입력 : ");
		num = sc.nextInt();
		
		switch(num % 2) {
		case 0:	System.out.println("짝수"); break;
		case 1: System.out.println("홀수"); 
		}
		
		// 의도적으로 break를 생략하여 같은 코드를 수행할 여러 case를 모아서 배치할 수 있다
		switch(num) {
		case 1:	// 1이면 여기서 시작하지만, 내용도 없고, break도 없어서 아래로 내려간다
		case 3:
		case 5:
			System.out.println("홀수입니다");
			break;
		case 2: case 4: case 6:
			System.out.println("짝수입니다");
		}
		
//		3) switch에는 상수(리터럴)값을 사용할 수 없다 => 있다
//		case 에 변수를 사용할 수 없다
		String word = "Hello";
		
//		switch("Hello") {
//		case word: // case에는 변수를 둘 수 없다 (상수만 허용된다)
//			System.out.println("5");
//		}
		
		
	}
}
