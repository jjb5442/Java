package control;

import java.util.Scanner;

public class Quiz1 {
	public static void main(String[] args) {
		// 주민등록번호의 7번째 자리는 성별정보와 출생연도의 정보가 담겨있다
		// 홀수는 남성, 짝수는 여성을 의미하며
		// 9, 0은 1800년대 출생
		// 1, 2는 1900년대 출생
		// 3, 4는 2000년대 출생이다
		// 정수를 하나 입력받아서, 성별과 출생년대를 출력하세요
		// (switch문을 여러개 사용해도 됩니다)
		
		Scanner sc = new Scanner(System.in);
		int num;
		
		System.out.print("정수 입력 : ");
		num = sc.nextInt();
		
		switch(num) {
		case 9: case 0:
			System.out.print("1800년대 출생");
			break;
		case 1: case 2:
			System.out.print("1900년대 출생");
			break;
		case 3: case 4:
			System.out.print("2000년대 출생");
			break;
		}
		switch(num % 2) {
		case 1: System.out.println(", 남성입니다"); break;
		case 0: System.out.println(", 여성입니다"); break;
		}
		sc.close();
		
		
	}
}
