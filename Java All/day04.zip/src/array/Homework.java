package array;

public class Homework {
	public static void main(String[] args) {
		// 3주차 토요일에 풀이할게요 !!
		
		// 배열 관련 문제
		
		// 1) 사용자에게 길이를 입력받아서 입력받은 크기만큼의 배열을 생성하고, 출력하세요
		
		// 2) Random을 이용하여 배열의 각 멤버에 길이보다 작은 랜덤값을 넣고 출력하세요
		
		// 3) [선택정렬 알고리즘] 을 검색해보고 가능하면 정렬한 후 다시 출력하세요
		// 작은 값이 앞으로 정렬되도록
		
	}
}
