package array;

public class Ex12 {
	public static void main(String[] args) {
		// 배열의 선언 방식
		int[] arr1 = { 1, 2, 3 };
		int arr2[] = { 4, 5, 6 };
		int[] arr3 = new int[] { 7, 8, 9 };	// 멤버 요소를 지정
		int[] arr4 = new int[3];			// 길이를 지정(멤버는 비어있음)
		int[] arr5;
//		int[] arr6 = new int[3] { 10, 11, 12 };
//		길이와 멤버를 동시에 지정할 수 없다
//		길이를 지정하는 것은 비어있는 배열을 만든다는 의미이다
		
//		arr1은 { 1, 2, 3 } 배열을 가리킨다
//		arr2는 { 4, 5, 6 } 배열을 가리킨다 (배열 괄호를 변수이름 뒤에 적어도 허용)
//		arr3는 새로운 배열 { 7, 8, 9 } 를 생성하고, 그 곳을 가리킨다
//		arr4는 길이 3짜리의 새로운 배열을 생성하고, 그 곳을 가리킨다
//		arr5는 정수형 배열을 가리킬 수 있는 변수이지만, 현재는 값이 없다
		
//		배열은 primitive Type이 아니라, 
//		Reference Type이기 때문에 참조방식으로 대상을 가리킨다
		
		arr5 = new int[]{ 10, 20, 30 };
//		arr5 = { 10, 20, 30 };
//		Array constants can only be used in initializers
//		배열에 상수를 지정하는 것은 초기화때에만 가능합니다
		
		
	}
}
