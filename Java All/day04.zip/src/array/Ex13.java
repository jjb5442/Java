package array;

import java.util.Random;

public class Ex13 {
	public static void main(String[] args) {
		// 1) 길이 5짜리의 배열을 선언
		// 멤버를 지정하지 않으면, 초기값은 자료형에 맞게 0에 해당하는 값으로 초기화된다
		int[] arr = new int[10];
		
		System.out.print("1) arr : ");
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");	// 배열의 멤버를 출력
		} System.out.println();	// 줄바꿈
		
		// 2) Random을 이용하여 1부터 9 사이의 아무 숫자나 순서대로 넣어주기
		Random ran = new Random();
		for(int i = 0; i < arr.length; i++) {
			arr[i] = ran.nextInt(9) + 1;
		}
		
		// 3) 배열에 저장되어 있는 각 요소를 순서대로 출력
		System.out.print("3) arr : ");
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");	// 배열의 멤버를 출력
		} System.out.println();	// 줄바꿈
	}
}
