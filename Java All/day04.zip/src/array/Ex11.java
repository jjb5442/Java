package array;

public class Ex11 {
	public static void main(String[] args) {
		// 여러 값을 배열로 묶어서 저장
		int[] arr = { 1, 2, 3 };
		for(int i = 0; i < arr.length; i++) {// 자바의 배열은 길이정보를 포함
			arr[i] *= 10;
			System.out.println(arr[i]); 	// 배열의 i번째 요소
			// 배열의 순번은 항상 0부터 시작하여, 길이 - 1 까지 참조할 수 있다
		}
		// 배열은 여러 데이터를 묶은 형태이다
		// 각 데이터는 변수에 저장한다
		// 따라서 배열의 멤버는 일반 변수와 동일하게 취급할 수 있다
		// 일반 변수처럼 연산, 참조, 출력, 대입 모든 작동을 수행할 수 있다
		// 단, 배열의 순번은 길이를 벗어나면 안된다
		
		// 여러 값을 각각의 변수에 저장 (한번에 처리할 수 없음)
		int n1 = 1, n2 = 2, n3 = 3;
//		for(int i = 1; i <= 3; i++) {
//			System.out.println(n + i);
//		}
	}
}
