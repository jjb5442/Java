package array;

import java.util.Random;

public class Ex13_Compare {
	public static void main(String[] args) {
		// 배열을 쓰면서 반복문을 사용하지 않는다면?
		int[] arr = new int[50];
		
		System.out.print("1) arr : ");
		System.out.print(arr[0] + " ");
		System.out.print(arr[1] + " ");
		System.out.print(arr[2] + " ");
		System.out.print(arr[3] + " ");
		System.out.print(arr[4] + " ");
		System.out.println();
		
		Random ran = new Random();
		arr[0] = ran.nextInt(9) + 1;
		arr[1] = ran.nextInt(9) + 1;
		arr[2] = ran.nextInt(9) + 1;
		arr[3] = ran.nextInt(9) + 1;
		arr[4] = ran.nextInt(9) + 1;
		
		System.out.print("3) arr : ");
		System.out.print(arr[0] + " ");
		System.out.print(arr[1] + " ");
		System.out.print(arr[2] + " ");
		System.out.print(arr[3] + " ");
		System.out.print(arr[4] + " ");
		System.out.println();
	}
}
