package dataType;

public class Quiz2 {
	public static void main(String[] args) {
		// 체질량지수(BMI)는 자신의 몸무게(kg)를 키의 제곱(m)으로 나눈 값입니다
		// 근육량, 유전적 원인, 개인차를 반영하지는 못하므로, 참고자료로 활용하면 됩니다
		// 정수형태로 키와 몸무게를 변수로 선언하여 값을 넣으세요
		// 이때 키는 cm, 몸무게는 kg단위로 값을 넣어줍니다
		// 위 내용에 따라 bmi 값을 구하여 출력하세요
		
		int weight = 75, height = 180;	// -> 1.8
		double h;
		double bmi;
		
		h = height / (double)100;
		bmi = weight / (h * h);
		
		System.out.println(bmi);
		
		// bmi값에 따라서 아래 상태를 문자열형태로 출력할 수도 있다
		// bmi값의 소수점 특정 자릿수까지만 출력하는 서식도 추가할 수 있다
		
		// 참고 
		// ~ 18.5 	: 저체중
		// ~ 23 	: 정상
		// ~ 25 	: 과체중
		// 25 ~ 	: 비만
	}
}
