package dataType;

public class Ex02 {
	public static void main(String[] args) {
		int n1 = 322;
		int n2 = 127;
		
		int plus = n1 + n2;
		int minus = n1 - n2;
		int mul = n1 * n2;
		int div = n1 / n2;
		int rem = n1 % n2;
		
		System.out.println("더하기 : " + plus);	// 여러 글자는 문자열이라고 한다
		System.out.println("빼기 : " + minus);	// 문자열은 "쌍따옴표" 로 묶는다
		System.out.println("곱하기 : " + mul);		// 문자열 더하기는 이어붙이기로 처리
		System.out.println("나누기 : " + div);		// 문자열은 숫자가 아니기 때문에
		System.out.println("나머지 : " + rem);
	}
}
