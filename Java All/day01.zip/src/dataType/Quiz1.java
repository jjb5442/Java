package dataType;

public class Quiz1 {
	public static void main(String[] args) {
		// 문제1) 버스 한 구간 당 걸리는 평균 시간이 3분 이라고 가정한다
		// A라는 사람은 14구간을 이동했고
		// B라는 사람은 22구간을 이동했다
		// 각각 걸리는 예상시간을 화면에 출력하세요
		// (이동시간을 시, 분 단위로 나누어서 출력해보세요)
		
		// step1) 문제를 읽고 필요한 변수를 미리 선언한다	(문제를 먼저 파악해야 한다)
		int perSection = 3;	// 분 단위 시간
		int a = 7;			// 구간 수
		int b = 30;			// 구간 수
		int aMin, aHour, bMin, bHour;
		
		// step2) 입력받거나, 계산해서 변수의 값을 모두 채운다	(계산, 답 구하기)
		a = a * perSection;
		b = b * perSection;
		aHour = a / 60;
		aMin = a % 60;
		bHour = b / 60;
		bMin = b % 60;
		
		// step3) 문제에서 요구하는 정답을 형식에 맞게 출력한다	(출력)
		System.out.println("A는 " + aHour + "시간 " + aMin + "분 걸렸습니다");
		System.out.println("B는 " + bHour + "시간 " + bMin + "분 걸렸습니다");
		
		
	}
}
