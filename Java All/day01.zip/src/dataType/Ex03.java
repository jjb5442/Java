package dataType;

public class Ex03 {
	public static void main(String[] args) {
		// 변수 만들기 (변수 선언) 		: [자료형] [변수이름];
		// 변수 만들면서 값 넣기 (초기화) 	: [자료형] [변수이름] = [값];
		// 만들어진 변수에 값 넣기 (대입)	: [변수이름] = [값];
		
		// 이미 사용중인 변수이름으로 새로운 변수를 만들 수 없다
		// 한번 만들어진 변수는 함수가 끝날때 까지 사용할 수 있다
		// 변수만 만들고 값을 넣지 않으면 값을 계산하거나 출력할 수 없다
		
		// 예시1) 올해연도와 출생년도를 변수로 선언하고 우리나라식의 나이를 출력하세요
		int currentYear = 2022;
		int birthYear = 1999;
		
		int age = currentYear - birthYear + 1;
		
		System.out.println("올해 나이는 " + age + "살입니다");
		System.out.println(); 	// 기본출력문만 적고 내용이 없으면 한줄 밑으로 내린다
		
		// 예시2) 원하는 시간을 초 단위로 변수에 저장하고, 그 값을 분과 초로 나누어서 출력하세요
		int time = 7200;
		int min, sec; 	// 변수를 선언만 하기, 같은 자료형의 여러 변수를 선언할 수 있다
		
		min = time / 60; 	// 분은 시간을 60초로 나눈 몫
		sec = time % 60;	// 초는 시간을 60초로 나눈 나머지
		
		System.out.println(time + "초는 " + min + "분 " + sec + "초입니다");
				
		
		
		
		
	}
}
