package dataType;

public class Ex04 {
	public static void main(String[] args) {
		// 예제) 3과목의 점수를 정수로 지정하고, 합계와 평균 구하여 출력하기
		// 단, 평균은 실수형태로 출력하기 (소수점 이하 자리가 출력되어야 함)
		
		int kor = 100, eng = 99, mat = 87, sum = 0;		// 정수
		double avg;										// 실수
		
		sum = kor + eng + mat;
		avg = sum / 3;	// 정수와 정수를 계산하면 그 결과는 정수형태로 나온다
						// 정수와 실수를 계산하면 그 결과는 실수형태로 나온다
		// 어떤 데이터의 자료형을 변경해야 하는 경우가 있다 (자료형 변환)
		avg = sum / (double)3;	// 값 앞에 () 를 적고 안에 원하는 자료형을 작성하면 된다
		avg = sum / 3.0;
		
		System.out.println("합계 : " + sum);
		System.out.println("평균 : " + avg);
	}
}
