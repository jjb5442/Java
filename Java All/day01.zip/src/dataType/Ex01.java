package dataType;

// 자바 코드 작성 기본 규칙
// 1) 클래스의 이름은 반드시 첫 글자를 대문자로 작성한다
// 2) 클래스를 제외한 프로젝트, 패키지, 변수, 함수의 이름은 소문자로 시작한다
// 3) 한 문장이 끝나면 ; 으로 마무리한다. 단, 의미상 문장이 끝났을 때만 찍어준다
// ex) 만약 내 나이가 20살 이하라면...; 이렇게 마무리하면 안됨
// 4) { } 중괄호는 영역을 구분하기 위한 기호이다. 시작 괄호와 마무리 괄호의 짝을 맞춰준다
// 5) 적절한 들여쓰기를 이용하여 영역 구분을 쉽게 할 수 있도록 작성한다

public class Ex01 {
	public static void main(String[] args) {
		// primitive type (기본 자료형, 원시 자료형)
		// 컴퓨터가 쉽게 이해할 수 있는 숫자 기반의 자료형
		// 클래스 형식이 아니라서, 첫글자는 모두 소문자이다
		// 변수 선언 - [자료형] [변수이름];
		// 변수 : 값을 저장할 수 있는 (메모리) 공간
		
/**/	boolean bo;	// 논리값		true / false	1 byte
		byte by;	// 정수		-128 ~ +127		1 byte
		short sh;	// 정수		-32768 ~ 32767	2 byte
		char ch;	// 정수(글자)	0 ~ 65535		2 byte
/**/	int num;	// 정수		-21억 ~ 21억		4 byte
		long ln;	// 정수		+-922해			8 byte
		float fl;	// 실수						4 byte
/**/	double db;	// 실수						8 byte

		by = 127;
		System.out.println(by); 	// 127
		
		by = (byte)200;
		System.out.println(by); 	// -56
		
		ch = 65;
		System.out.println(ch); 	// A
		
		ch = 44032;
		System.out.println(ch); 	// 가
		
		ch = '나';	// 정수를 저장해야 하지만, 홑따옴표로 묶어서 글자를 저장할 수도 있다
		System.out.println(ch);
		
		ch = 'B';
		System.out.println(ch);
		System.out.println((int)ch);
	}
}











