package summary3;
// 서브클래스는 슈퍼클래스의 생성자를 호출해야 한다
public class Cat extends Animal {
	Cat(String name) {
		super(name);
	}
}
