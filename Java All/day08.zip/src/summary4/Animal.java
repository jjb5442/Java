package summary4;
// 공통점은 하나의 슈퍼클래스에 작성
public class Animal {
	String name;
	Animal(String name) {
		this.name = name;
	}
}
