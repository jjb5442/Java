package summary2;

public class Dog extends Animal {
	Dog(String name) {
		super(name);
	}
}
